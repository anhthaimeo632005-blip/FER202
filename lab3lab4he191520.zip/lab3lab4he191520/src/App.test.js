import { fireEvent, render, screen } from '@testing-library/react';
import App from './App';

beforeEach(() => window.history.replaceState({}, '', '/'));

test('hiển thị trang chủ và danh sách 15 sản phẩm', () => {
  render(<App />);
  fireEvent.click(screen.getByRole('link', { name: 'View Products' }));
  expect(screen.getByText('Total Products: 15')).toBeInTheDocument();
  expect(screen.getByText('Trang: 1/5')).toBeInTheDocument();
});

test('tìm kiếm khi gửi form và lưu keyword trong URL', () => {
  window.history.replaceState({}, '', '/products'); render(<App />);
  fireEvent.change(screen.getByRole('searchbox'), { target: { value: 'iPhone' } });
  expect(screen.getByText('Total Products: 15')).toBeInTheDocument();
  fireEvent.click(screen.getByRole('button', { name: 'Tìm kiếm' }));
  expect(screen.getByText('Total Products: 1')).toBeInTheDocument();
  expect(window.location.search).toContain('keyword=iPhone');
});

test('lọc danh mục và phân trang', () => {
  window.history.replaceState({}, '', '/products'); render(<App />);
  fireEvent.change(screen.getByLabelText('Danh mục'), { target: { value: 'Laptop' } });
  expect(screen.getByText('Total Products: 4')).toBeInTheDocument();
  fireEvent.click(screen.getByRole('button', { name: 'Tiếp' }));
  expect(screen.getByText('Trang: 2/2')).toBeInTheDocument();
  expect(window.location.search).toContain('category=Laptop');
  expect(window.location.search).toContain('page=2');
});

test('đường dẫn sản phẩm hợp lệ hiển thị chi tiết; ID sai báo không tìm thấy', () => {
  window.history.replaceState({}, '', '/products/1');
  const view = render(<App />);
  expect(screen.getByRole('heading', { name: 'iPhone 16' })).toBeInTheDocument();
  view.unmount();
  window.history.replaceState({}, '', '/products/999');
  render(<App />);
  expect(screen.getByText('Sản phẩm có ID 999 không tồn tại.')).toBeInTheDocument();
});

test('đường dẫn không hợp lệ hiển thị trang 404', () => {
  window.history.replaceState({}, '', '/khong-ton-tai');
  render(<App />);
  expect(screen.getByRole('heading', { name: 'Không tìm thấy trang' })).toBeInTheDocument();
});

test('lọc không có kết quả và trang URL vượt giới hạn không làm vỡ danh sách', () => {
  window.history.replaceState({}, '', '/products?keyword=khongco&page=999');
  render(<App />);
  expect(screen.getByText('Không có sản phẩm phù hợp.')).toBeInTheDocument();
  expect(screen.getByText('Trang: 1/1')).toBeInTheDocument();
});
