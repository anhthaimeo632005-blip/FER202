import { Link } from 'react-router-dom';

export default function NotFound() { return <main className="container"><section className="hero"><p className="eyebrow">404</p><h1>Không tìm thấy trang</h1><p>Trang bạn đang tìm kiếm không tồn tại.</p><Link className="button button-primary" to="/">Về trang chủ</Link></section></main>; }
