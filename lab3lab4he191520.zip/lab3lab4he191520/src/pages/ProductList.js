import { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { products } from '../data';
import SearchBar from '../components/SearchBar';
import CategoryFilter from '../components/CategoryFilter';
import ProductItem from '../components/ProductItem';

const PAGE_SIZE = 3;
export default function ProductList() {
  const [params, setParams] = useSearchParams(); const keyword = params.get('keyword') || ''; const category = params.get('category') || ''; const requested = Math.max(1, Number(params.get('page')) || 1);
  const categories = useMemo(() => [...new Set(products.map((p) => p.category))], []);
  const filtered = products.filter((p) => (!category || p.category === category) && (!keyword || p.name.toLocaleLowerCase('vi-VN').includes(keyword.toLocaleLowerCase('vi-VN'))));
  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE)); const page = Math.min(requested, totalPages); const visible = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const update = (key, value) => { const next = new URLSearchParams(params); value ? next.set(key, value) : next.delete(key); next.delete('page'); setParams(next); };
  const go = (value) => { const next = new URLSearchParams(params); next.set('page', value); setParams(next); };
  return <main className="container content"><div className="page-title"><p className="eyebrow">KHÁM PHÁ</p><h1>Danh sách sản phẩm</h1><p>Tìm kiếm và khám phá sản phẩm phù hợp với bạn.</p></div><section className="panel"><div className="filters"><SearchBar keyword={keyword} onSearch={(value) => update('keyword', value)} /><CategoryFilter category={category} categories={categories} onChange={(value) => update('category', value)} /></div><div className="list-meta"><strong role="status">Total Products: {filtered.length}</strong><nav className="pagination" aria-label="Phân trang"><button className="button button-outline" disabled={page === 1} onClick={() => go(page - 1)}>Trước</button><span>Trang: {page}/{totalPages}</span><button className="button button-outline" disabled={page === totalPages} onClick={() => go(page + 1)}>Tiếp</button></nav></div>{visible.length ? <div className="table-scroll"><table><thead><tr><th>ID</th><th>Tên sản phẩm</th><th>Danh mục</th><th>Giá</th><th>Thao tác</th></tr></thead><tbody>{visible.map((product) => <ProductItem key={product.id} product={product} />)}</tbody></table></div> : <div className="empty-state">Không có sản phẩm phù hợp.</div>}</section></main>;
}
