import { useNavigate, useParams } from 'react-router-dom';
import { products } from '../data';

const price = (value) => new Intl.NumberFormat('vi-VN').format(value) + 'đ';
export default function ProductDetail() {
  const { id } = useParams(); const navigate = useNavigate(); const product = products.find((item) => String(item.id) === id);
  return <main className="container content"><button className="back-button" onClick={() => navigate('/products')}>← Quay lại danh sách</button>{!product ? <section className="message-panel"><h1>Không tìm thấy sản phẩm</h1><p>Sản phẩm có ID {id} không tồn tại.</p></section> : <article className="detail-card"><div className="product-visual"><span aria-hidden="true">▣</span><span>Ảnh sản phẩm {product.id}</span></div><div className="detail-content"><span className="tag">{product.category}</span><h1>{product.name}</h1><dl><div><dt>ID</dt><dd>{product.id}</dd></div><div><dt>Danh mục</dt><dd>{product.category}</dd></div><div><dt>Giá</dt><dd className="price">{price(product.price)}</dd></div><div><dt>Mô tả</dt><dd>{product.description}</dd></div></dl></div></article>}</main>;
}
