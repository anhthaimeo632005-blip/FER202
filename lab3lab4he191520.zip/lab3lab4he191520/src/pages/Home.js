import { Link } from 'react-router-dom';

export default function Home() {
  return <main className="container"><section className="hero"><p className="eyebrow">PRODUCTSTORE</p><h1>Welcome to ProductStore</h1><p>Manage and explore products for your needs.</p><Link className="button button-primary" to="/products">View Products</Link></section></main>;
}
