import { Link } from 'react-router-dom';

const price = (value) => new Intl.NumberFormat('vi-VN').format(value) + 'đ';
export default function ProductItem({ product }) {
  return <tr><td data-label="ID">{product.id}</td><td data-label="Tên sản phẩm"><strong>{product.name}</strong></td><td data-label="Danh mục">{product.category}</td><td data-label="Giá" className="price">{price(product.price)}</td><td data-label="Thao tác"><Link className="detail-link" to={`/products/${product.id}`}>Chi tiết</Link></td></tr>;
}
