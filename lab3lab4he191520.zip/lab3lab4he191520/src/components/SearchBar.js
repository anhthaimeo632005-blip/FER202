import { useEffect, useState } from 'react';

export default function SearchBar({ keyword, onSearch }) {
  const [value, setValue] = useState(keyword);
  useEffect(() => setValue(keyword), [keyword]);
  return <form className="search-form" role="search" onSubmit={(e) => { e.preventDefault(); onSearch(value.trim()); }}><label htmlFor="keyword">Tìm sản phẩm</label><div className="search-input-group"><input id="keyword" type="search" placeholder="Tìm tên sản phẩm..." value={value} onChange={(e) => setValue(e.target.value)} /><button className="button button-primary" type="submit">Tìm kiếm</button></div></form>;
}
