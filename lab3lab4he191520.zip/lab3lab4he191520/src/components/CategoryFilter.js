export default function CategoryFilter({ category, categories, onChange }) {
  return <div className="field"><label htmlFor="category">Danh mục</label><select id="category" value={category} onChange={(e) => onChange(e.target.value)}><option value="">Tất cả danh mục</option>{categories.map((item) => <option key={item} value={item}>{item}</option>)}</select></div>;
}
