import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import Home from './pages/Home';
import ProductList from './pages/ProductList';
import ProductDetail from './pages/ProductDetail';
import NotFound from './pages/NotFound';
import './App.css';

export default function App() {
  return <BrowserRouter><Header /><Routes><Route path="/" element={<Home />} /><Route path="/products" element={<ProductList />} /><Route path="/products/:id" element={<ProductDetail />} /><Route path="*" element={<NotFound />} /></Routes></BrowserRouter>;
}
